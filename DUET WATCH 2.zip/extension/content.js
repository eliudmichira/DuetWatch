// ============================================================
//  Duet — Content Script
// ============================================================

(function () {
  if (window.__duetInjected) return;
  window.__duetInjected = true;

  let video = null;
  let isApplyingRemote = false;
  let expectedRemoteEvents = new Set();
  let applySettleTimer = null;
  let applySafetyTimer = null;
  let connected = false;
  let peerCount = 0;
  let lastSentSig = "";
  let lastSentAt = 0;
  let lastTabInfoAt = 0;
  let tabInfoTimer = null;
  let adInProgress = false;   // suppress sync while we're watching/skipping an ad
  let contextInvalid = false; // set true once the extension is reloaded/uninstalled
  let partnerName = "";       // last known display name of the partner (from SYNC_STATUS)
  let partnerEmoji = "";      // last known avatar emoji of the partner

  function syncBtnDefaultLabel() {
    return `Catch up to ${partnerName || "partner"}`;
  }
  function refreshSyncBtnLabel() {
    const btn = document.getElementById("__pp_sync_btn");
    if (!btn || btn.disabled) return; // don't clobber transient states
    btn.textContent = syncBtnDefaultLabel();
  }

  // Returns true if the background is still reachable. If not, marks the page
  // as dead so periodic timers can self-terminate.
  function extAlive() {
    if (contextInvalid) return false;
    try {
      if (!chrome.runtime?.id) { contextInvalid = true; teardown(); return false; }
      return true;
    } catch {
      contextInvalid = true;
      teardown();
      return false;
    }
  }

  // ── Echo suppression ───────────────────────────────────────
  // When we apply a remote state, we trigger seek/play/pause/ratechange on the
  // <video>. Those raise the corresponding events, which our listeners would
  // otherwise treat as fresh user actions and broadcast back. We track which
  // events we *expect* from a remote apply and consume them silently, clearing
  // the flag once they all arrive (with a small grace period for late-firing
  // events like 'playing' on slow streams) or after a 2s safety net.
  function endApplyingRemote() {
    isApplyingRemote = false;
    expectedRemoteEvents.clear();
    if (applySettleTimer) { clearTimeout(applySettleTimer); applySettleTimer = null; }
    if (applySafetyTimer) { clearTimeout(applySafetyTimer); applySafetyTimer = null; }
  }
  // Returns true if the event was an expected echo (caller should NOT broadcast).
  function consumeRemoteEvent(name) {
    if (!isApplyingRemote) return false;
    if (!expectedRemoteEvents.has(name)) {
      // Still in the apply window but this event wasn't expected — likely a
      // delayed echo (e.g., 'playing' after we already cleared 'play'). Treat
      // it as an echo too, since the user can't realistically have acted yet.
      return true;
    }
    expectedRemoteEvents.delete(name);
    if (expectedRemoteEvents.size === 0) {
      if (applySettleTimer) clearTimeout(applySettleTimer);
      applySettleTimer = setTimeout(endApplyingRemote, 250);
    }
    return true;
  }

  // Wrapper around chrome.runtime.sendMessage that never throws and never rejects.
  // (Raw sendMessage throws SYNCHRONOUSLY on "Extension context invalidated", so
  // .catch() alone isn't enough.)
  function safeSend(msg) {
    if (!extAlive()) return Promise.resolve(null);
    try {
      const p = chrome.runtime.sendMessage(msg);
      return p && typeof p.catch === "function" ? p.catch(() => null) : Promise.resolve(null);
    } catch {
      contextInvalid = true;
      teardown();
      return Promise.resolve(null);
    }
  }

  function teardown() {
    try { observer?.disconnect(); } catch {}
    if (tabInfoTimer)   { clearInterval(tabInfoTimer);   tabInfoTimer   = null; }
    if (ytAdTimer)      { clearInterval(ytAdTimer);      ytAdTimer      = null; }
    if (yflixSkipTimer) { clearInterval(yflixSkipTimer); yflixSkipTimer = null; }
    // Hide the badge — extension is gone, anything it claims is stale
    const badge = document.getElementById("__duet_badge");
    if (badge) badge.style.opacity = "0";
  }

  let ytAdTimer = null;
  let yflixSkipTimer = null;

  // ── Video Detection ────────────────────────────────────────
  function scoreVideo(v) {
    const r = v.getBoundingClientRect();
    const visible = r.width > 0 && r.height > 0 && getComputedStyle(v).visibility !== "hidden";
    if (!visible) return 0;
    const area = r.width * r.height;
    const ready = v.readyState >= 2 ? 1 : 0;
    return area + ready * 1_000_000;
  }
  function findVideo() {
    const videos = Array.from(document.querySelectorAll("video"));
    if (!videos.length) return null;
    let best = null, bestScore = 0;
    for (const v of videos) {
      const s = scoreVideo(v);
      if (s > bestScore) { best = v; bestScore = s; }
    }
    return best;
  }
  function attachListeners(v) {
    if (v.__duetAttached) {
      video = v; // just update pointer if already attached
      return;
    }
    v.__duetAttached = true;
    video = v;
    const guard = (fn) => () => { 
      if (video !== v) return; // Drop events from old hidden videos
      try { fn(); } catch { contextInvalid = true; teardown(); } 
    };
    v.addEventListener("play",       guard(() => { if (consumeRemoteEvent("play"))    return; sendSync("play");  sendTabInfo(true); }));
    v.addEventListener("pause",      guard(() => { if (consumeRemoteEvent("pause"))   return; sendSync("pause"); sendTabInfo(true); }));
    v.addEventListener("seeked",     guard(() => { if (consumeRemoteEvent("seeked"))  return; sendSync(v.paused ? "pause" : "play"); sendTabInfo(true); }));
    v.addEventListener("ratechange", guard(() => { if (consumeRemoteEvent("ratechange")) return; sendSync(v.paused ? "pause" : "play"); sendTabInfo(true); }));
    v.addEventListener("waiting",    guard(() => { if (isApplyingRemote) return; sendSync("pause"); safeSend({ type: "SEND_REACTION", emoji: "⏳ Buffering..." }); }));
    v.addEventListener("playing",    guard(() => { if (consumeRemoteEvent("playing")) return; sendSync("play");  sendTabInfo(true); }));
    v.addEventListener("timeupdate", guard(() => { sendTabInfo(); }));
    console.log("[Duet] Attached to active video player.");
    updateOverlay();
    sendTabInfo(true); // immediately push our metadata
  }

  // Streaming sites often keep old video elements hidden in the DOM.
  // Polling continuously ensures we always lock onto the currently visible video.
  setInterval(() => {
    if (!extAlive()) return;
    const best = findVideo();
    if (best && best !== video) {
      attachListeners(best);
    }
  }, 1500);

  // ── Send local action ──────────────────────────────────────
  function sendSync(action) {
    if (isApplyingRemote || !connected || !video) return;
    if (adInProgress) return; // don't push ad-video timestamps to partner
    const sig = `${action}|${video.currentTime.toFixed(2)}`;
    const now = Date.now();
    if (sig === lastSentSig && now - lastSentAt < 250) return;
    lastSentSig = sig;
    lastSentAt = now;

    safeSend({
      type: "SYNC_EVENT",
      state: {
        action,
        currentTime: video.currentTime,
        playbackRate: video.playbackRate
      }
    });
  }

  // ── Apply Remote Sync ──────────────────────────────────────
  function applySync(state, serverNow) {
    if (!video) {
      video = findVideo();
      if (!video) return;
    }

    // Reset any in-flight apply window so we don't carry stale expectations.
    endApplyingRemote();
    isApplyingRemote = true;
    const expected = new Set();

    let targetTime = state.currentTime;
    if (state.action === "play" && typeof state.serverTime === "number" && typeof serverNow === "number") {
      const elapsed = Math.max(0, (serverNow - state.serverTime) / 1000);
      targetTime = state.currentTime + elapsed;
    }

    // Force-syncs always seek; normal updates only seek when drifting > 1s
    const driftThreshold = state.force ? 0 : 1.0;
    if (Math.abs(video.currentTime - targetTime) > driftThreshold) {
      try { video.currentTime = targetTime; expected.add("seeked"); } catch {}
    }

    if (state.playbackRate && Math.abs(video.playbackRate - state.playbackRate) > 0.01) {
      try { video.playbackRate = state.playbackRate; expected.add("ratechange"); } catch {}
    }

    if (state.action === "play" && video.paused) {
      expected.add("play");
      expected.add("playing");
      video.play().catch(() => showFlash("play", "Click the video to start (autoplay blocked)"));
    } else if (state.action === "pause" && !video.paused) {
      expected.add("pause");
      video.pause();
    }

    showFlash(state.action, state.force ? `${partnerName || "Partner"} re-synced you` : null);

    expectedRemoteEvents = expected;
    if (expected.size === 0) {
      // Nothing to wait for — clear immediately so the user isn't suppressed.
      endApplyingRemote();
    } else {
      // Safety net: even if the player never emits the events we expect (slow
      // HLS, buggy embed), don't lock out the user beyond 2 seconds.
      applySafetyTimer = setTimeout(endApplyingRemote, 2000);
    }
  }

  // ── Tab metadata (what am I watching) ──────────────────────
  function getVideoTitle() {
    // YouTube-specific
    const yt = document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.title.ytd-video-primary-info-renderer");
    if (yt?.textContent?.trim()) return yt.textContent.trim();
    // OpenGraph
    const og = document.querySelector('meta[property="og:title"]')?.content;
    if (og) return og;
    return document.title;
  }

  // Only the top frame publishes tab metadata. Iframes (YouTube recommendations,
  // ad slots, sidecar players, etc.) used to spam TAB_INFO with the same tab.id
  // and overwrite the real player's metadata in Firebase, which made the partner
  // card render with empty/zero progress. If the actual player is in an iframe,
  // we defer to the top frame which still has access to the iframe's own video
  // via the page's DOM (or, for cross-origin iframes, to the iframe's <video>
  // tag scored by `findVideo()`).
  const isTopFrame = (() => {
    try { return window.top === window.self; } catch { return false; }
  })();

  // When running in a cross-origin iframe (yflix's embed, rapidshare, etc.),
  // location.href is a per-session tokenized URL that differs between viewers
  // even when they're on the same parent page. For partner-match purposes we
  // need the parent page's URL, which both partners actually share.
  //   - same-origin iframe: top.location.href works directly
  //   - cross-origin iframe: top.location.href is blocked. We fall back to
  //     a postMessage handshake with the top frame, then document.referrer,
  //     then our own location as last resort.
  //   - top frame: just location.href
  let topFrameUrl = "";  // populated via postMessage from the top frame
  function getPageUrl() {
    if (isTopFrame) return location.href;
    try { return window.top.location.href; } catch {}
    if (topFrameUrl) return topFrameUrl;
    if (document.referrer) return document.referrer;
    return location.href;
  }
  function getPageHostname() {
    try { return new URL(getPageUrl()).hostname.replace(/^www\./, ""); }
    catch { return location.hostname.replace(/^www\./, ""); }
  }

  // Top frame: respond to URL queries from embedded iframes, AND broadcast our
  // URL down on every history change (so SPA navigations stay in sync).
  // Iframe: ask the parent for its URL on load, then cache replies.
  if (isTopFrame) {
    const broadcastUrl = () => {
      const payload = { __duet_msg: "page-url", url: location.href };
      try {
        const frames = document.querySelectorAll("iframe");
        frames.forEach((f) => { try { f.contentWindow?.postMessage(payload, "*"); } catch {} });
      } catch {}
    };
    window.addEventListener("message", (e) => {
      if (e?.data?.__duet_msg === "request-page-url") {
        try { e.source?.postMessage({ __duet_msg: "page-url", url: location.href }, "*"); } catch {}
      }
    });
    // Re-broadcast on SPA navigation
    let lastHref = location.href;
    setInterval(() => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        broadcastUrl();
      }
    }, 1500);
    // Initial broadcast (after iframes have a chance to mount)
    setTimeout(broadcastUrl, 500);
  } else {
    window.addEventListener("message", (e) => {
      const data = e?.data;
      if (!data || data.__duet_msg !== "page-url" || typeof data.url !== "string") return;
      if (data.url !== topFrameUrl) {
        topFrameUrl = data.url;
        // Re-publish with the corrected URL right away so the partner card flips fast.
        if (connected && video) sendTabInfo(true);
      }
    });
    // Ask the parent on load (covers Referrer-Policy: no-referrer)
    const askParent = () => {
      try { window.parent?.postMessage({ __duet_msg: "request-page-url" }, "*"); } catch {}
    };
    askParent();
    setTimeout(askParent, 1000);
    setTimeout(askParent, 3000);
  }

  function sendTabInfo(force = false) {
    if (!connected || !video) return;
    // Only frames with a real, loaded video may publish metadata.
    // Empty ad/sidecar iframes have duration === 0 (or NaN) and are filtered
    // here. Live streams (HLS/DASH) have duration === Infinity, which passes
    // `> 0` so live partners still get to publish.
    if (!isTopFrame && !(video.duration > 0)) return;
    const now = Date.now();
    if (!force && now - lastTabInfoAt < 1000) return;
    lastTabInfoAt = now;

    const info = {
      // Always report the parent page URL so partner-match works even when
      // the player is in a cross-origin embed iframe.
      url: getPageUrl(),
      hostname: getPageHostname(),
      pageTitle: document.title,
      videoTitle: getVideoTitle(),
      duration: isFinite(video.duration) ? video.duration : 0,
      currentTime: video.currentTime,
      paused: video.paused
    };
    safeSend({ type: "TAB_INFO", info });
  }

  function startTabInfoTimer() {
    if (tabInfoTimer) clearInterval(tabInfoTimer);
    tabInfoTimer = setInterval(sendTabInfo, 1000);
  }
  document.addEventListener("visibilitychange", sendTabInfo);

  // Top frame listens for flash relays from cross-origin iframes (yflix, etc.)
  // so a single badge renders with all user-visible feedback.
  if (isTopFrame) {
    window.addEventListener("message", (e) => {
      const data = e?.data;
      if (!data || data.__duet_msg !== "flash") return;
      try { showFlash(data.action, data.customLabel); } catch {}
    });
  }

  // ── Visual Feedback (overlay + flash) ──────────────────────
  // The overlay (badge + flash) is rendered in the TOP frame only. Iframes
  // (yflix's cross-origin embed, etc.) still run sync logic but relay any
  // user-visible flash up to the top frame via postMessage so we don't get
  // duplicate badges floating on the page.
  function ensureOverlay() {
    if (!isTopFrame) return null;
    let overlay = document.getElementById("__duet_overlay");
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "__duet_overlay";
    overlay.style.cssText = `
      position: fixed; bottom: 22px; right: 22px; z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', sans-serif;
      pointer-events: none; display: flex; flex-direction: column;
      align-items: flex-end; gap: 8px;
    `;
    (document.documentElement || document.body).appendChild(overlay);
    restoreBadgePosition();
    return overlay;
  }

  // ── Draggable badge ────────────────────────────────────────
  // Anchors the overlay to top/left at (x, y), clamped inside the viewport
  // with an 8px gutter. Switches `align-items` so children flow downward
  // instead of upward (the default bottom-right anchor stacked flashes
  // above the badge; once dragged we want them stacking below it).
  function applyOverlayPosition(x, y) {
    const overlay = document.getElementById("__duet_overlay");
    if (!overlay) return;
    const rect = overlay.getBoundingClientRect();
    const w = rect.width  || 200;
    const h = rect.height || 60;
    const maxX = Math.max(8, window.innerWidth  - w - 8);
    const maxY = Math.max(8, window.innerHeight - h - 8);
    const cx = Math.max(8, Math.min(maxX, x));
    const cy = Math.max(8, Math.min(maxY, y));
    overlay.style.right  = "auto";
    overlay.style.bottom = "auto";
    overlay.style.left   = cx + "px";
    overlay.style.top    = cy + "px";
    overlay.style.alignItems = "flex-start";
  }
  function restoreBadgePosition() {
    try {
      chrome.storage.local.get(["__duet_badge_pos"], (data) => {
        const p = data && data.__duet_badge_pos;
        if (p && typeof p.x === "number" && typeof p.y === "number") {
          // Defer one frame so the overlay has measurable size before clamping.
          requestAnimationFrame(() => applyOverlayPosition(p.x, p.y));
        }
      });
    } catch {}
  }
  // Re-clamp on viewport resize so the badge doesn't end up off-screen when
  // the window shrinks or rotates.
  window.addEventListener("resize", () => {
    const overlay = document.getElementById("__duet_overlay");
    if (!overlay || overlay.style.left === "" || overlay.style.left === "auto") return;
    const x = parseFloat(overlay.style.left) || 0;
    const y = parseFloat(overlay.style.top)  || 0;
    applyOverlayPosition(x, y);
  });

  function installBadgeDrag(handle) {
    const DRAG_THRESHOLD = 4;
    let drag = null;

    handle.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      // Don't start drag from an interactive control inside the topbar.
      if (e.target instanceof Element && e.target.closest("button, input, a")) return;
      const overlay = document.getElementById("__duet_overlay");
      if (!overlay) return;
      const rect = overlay.getBoundingClientRect();
      drag = {
        startX: e.clientX, startY: e.clientY,
        origX:  rect.left, origY:  rect.top,
        moved: false, pointerId: e.pointerId
      };
      try { handle.setPointerCapture(e.pointerId); } catch {}
    });

    handle.addEventListener("pointermove", (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.startX;
      const dy = e.clientY - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
      drag.moved = true;
      handle.style.cursor = "grabbing";
      applyOverlayPosition(drag.origX + dx, drag.origY + dy);
      e.preventDefault();
    });

    const finish = (e) => {
      if (!drag) return;
      try { handle.releasePointerCapture(drag.pointerId); } catch {}
      handle.style.cursor = "grab";
      if (drag.moved) {
        const overlay = document.getElementById("__duet_overlay");
        if (overlay) {
          const rect = overlay.getBoundingClientRect();
          try { chrome.storage.local.set({ __duet_badge_pos: { x: rect.left, y: rect.top } }); } catch {}
        }
        // Swallow the synthetic click that would otherwise toggle hover state.
        const stop = (ev) => { ev.stopPropagation(); ev.preventDefault(); };
        handle.addEventListener("click", stop, { capture: true, once: true });
      }
      drag = null;
    };
    handle.addEventListener("pointerup", finish);
    handle.addEventListener("pointercancel", finish);
  }

  function updateOverlay() {
    if (!isTopFrame) return;
    const overlay = ensureOverlay();
    let badge = document.getElementById("__duet_badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.id = "__duet_badge";
      badge.style.cssText = `
        position: relative;
        background: linear-gradient(135deg, rgba(15,13,24,0.92), rgba(8,7,13,0.94));
        backdrop-filter: blur(16px) saturate(1.4);
        -webkit-backdrop-filter: blur(16px) saturate(1.4);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 16px;
        color: #f4f1ea; font-size: 11.5px; font-weight: 600; letter-spacing: 0.01em;
        box-shadow: 0 10px 28px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.04) inset;
        transition: opacity 0.35s, transform 0.35s;
        opacity: 0; transform: translateY(6px);
        display: flex; flex-direction: column; overflow: hidden; pointer-events: auto;
      `;
      
      const topBar = document.createElement("div");
      topBar.id = "__pp_topbar";
      topBar.style.cssText = "display: flex; align-items: center; gap: 8px; padding: 7px 14px 7px 11px; cursor: grab; touch-action: none; user-select: none;";
      badge.appendChild(topBar);

      // Drag the whole overlay by its top bar. Position is persisted to
      // chrome.storage so the badge stays where the user put it across loads.
      installBadgeDrag(topBar);

      const controls = document.createElement("div");
      controls.id = "__pp_controls";
      controls.style.cssText = "display: none; flex-direction: column; gap: 8px; padding: 0 14px 12px 14px;";
      
      controls.innerHTML = `
        <div style="height: 1px; background: rgba(255,255,255,0.1); width: 100%; margin-bottom: 2px;"></div>
        <button id="__pp_sync_btn" style="background: rgba(255,255,255,0.1); border: none; color: white; border-radius: 6px; padding: 6px; font-weight: 600; cursor: pointer; transition: background 0.2s; font-size: 11px;">${syncBtnDefaultLabel()}</button>
        <div style="display: flex; gap: 6px; justify-content: space-between;">
          ${['😂', '😮', '💖', '😭'].map(e => `<button class="__pp_re_btn" style="background: rgba(255,255,255,0.05); border: none; border-radius: 6px; cursor: pointer; font-size: 15px; padding: 4px 6px; transition: background 0.2s;">${e}</button>`).join('')}
        </div>
        <div style="position: relative;">
          <input id="__pp_chat_input" type="text" placeholder="Send a message…" maxlength="140" autocomplete="off" spellcheck="false" style="width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; padding: 6px 26px 6px 8px; color: #f4f1ea; font-family: inherit; font-size: 11px; outline: none; transition: border-color 0.2s;" />
          <span id="__pp_chat_hint" style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); font-size: 9px; color: rgba(244,241,234,0.4); pointer-events: none;">↵</span>
        </div>
      `;
      badge.appendChild(controls);

      // Interactions
      badge.addEventListener('mouseenter', () => { if(connected) controls.style.display = 'flex'; });
      badge.addEventListener('mouseleave', () => {
        // Don't collapse while the chat input is focused
        if (controls.dataset.locked === '1') return;
        controls.style.display = 'none';
      });

      const syncBtn = controls.querySelector('#__pp_sync_btn');
      syncBtn.addEventListener('mouseenter', () => syncBtn.style.background = 'rgba(255,255,255,0.2)');
      syncBtn.addEventListener('mouseleave', () => syncBtn.style.background = 'rgba(255,255,255,0.1)');
      syncBtn.addEventListener('click', async () => {
        if (syncBtn.disabled) return;
        syncBtn.disabled = true;
        const who = partnerName || "partner";
        syncBtn.textContent = "Catching up…";
        showFlash("play", `Catching up to ${who}…`);
        const res = await safeSend({ type: "CATCH_UP_TO_PARTNER" });
        if (res?.error) {
          showFlash("pause", res.error);
          syncBtn.textContent = "Try again";
        } else if (res?.ok) {
          syncBtn.textContent = "Caught up ✓";
        } else {
          syncBtn.textContent = syncBtnDefaultLabel();
        }
        setTimeout(() => {
          syncBtn.disabled = false;
          syncBtn.textContent = syncBtnDefaultLabel();
        }, 1800);
      });

      controls.querySelectorAll('.__pp_re_btn').forEach(btn => {
        btn.addEventListener('mouseenter', () => btn.style.background = 'rgba(255,255,255,0.15)');
        btn.addEventListener('mouseleave', () => btn.style.background = 'rgba(255,255,255,0.05)');
        btn.addEventListener('click', (e) => {
          safeSend({ type: "SEND_REACTION", emoji: e.target.textContent });
          spawnReaction(e.target.textContent); // Show locally
        });
      });

      // Inline chat — Enter sends a message via the existing reaction channel
      // (popup uses the same path), so partner sees it as a floating message.
      const chatInput = controls.querySelector('#__pp_chat_input');
      if (chatInput) {
        chatInput.addEventListener('focus', () => { chatInput.style.borderColor = 'rgba(244,114,182,0.5)'; });
        chatInput.addEventListener('blur',  () => { chatInput.style.borderColor = 'rgba(255,255,255,0.1)'; });
        // Don't let typing trigger site-level shortcuts (YouTube j/k/l, space, etc.)
        chatInput.addEventListener('keydown', (e) => {
          e.stopPropagation();
          if (e.key === 'Enter') {
            const text = chatInput.value.trim().slice(0, 140);
            if (!text) return;
            safeSend({ type: "SEND_REACTION", emoji: text });
            spawnReaction(text);
            chatInput.value = '';
            chatInput.style.borderColor = '#5ee2a0';
            setTimeout(() => { chatInput.style.borderColor = 'rgba(244,114,182,0.5)'; }, 500);
          }
        });
        // Keep the controls panel open while typing, even if the mouse drifts off.
        chatInput.addEventListener('focus', () => { controls.dataset.locked = '1'; });
        chatInput.addEventListener('blur',  () => { delete controls.dataset.locked; });
      }

      overlay.appendChild(badge);
    }
    
    if (connected) {
      let color = "#ffc89a";
      let text = "waiting for partner";
      let emoji = partnerEmoji || "👋";

      if (peerCount >= 2) {
        if (currentDriftStatus === "sync")           { color = "#5ee2a0"; text = "in sync";           emoji = "💞"; }
        else if (currentDriftStatus === "warning")   { color = "#fcd34d"; text = "slight delay";     emoji = "⏳"; }
        else if (currentDriftStatus === "out_of_sync") { color = "#ef4444"; text = "out of sync";    emoji = "⚠️"; }
        else if (currentDriftStatus === "mismatch")  { color = "#ef4444"; text = "different video"; emoji = "🎬"; }
        else                                          { color = "#ffc89a"; text = "waiting for video"; emoji = "📺"; }
      }

      document.getElementById("__pp_topbar").innerHTML = `
        <span style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 8px ${color}, 0 0 0 3px ${color}1f;display:inline-block;transition:all 0.3s;"></span>
        <span style="background:linear-gradient(110deg,#ffc89a,#f472b6,#8b5cf6);-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:700">Duet</span>
        <span style="color:rgba(244,241,234,0.55);font-weight:500">·</span>
        <span style="font-size:12px;line-height:1;">${emoji}</span>
        <span style="color:rgba(244,241,234,0.85);transition:color 0.3s;">${text}</span>
      `;
      badge.style.opacity = "1";
      badge.style.transform = "translateY(0)";
    } else {
      badge.style.opacity = "0";
      badge.style.transform = "translateY(6px)";
      document.getElementById("__pp_controls").style.display = 'none';
    }
  }

  function showFlash(action, customLabel) {
    // From an iframe, relay the flash request up to the top frame instead of
    // rendering a duplicate badge on the page.
    if (!isTopFrame) {
      try {
        window.top.postMessage({ __duet_msg: "flash", action, customLabel }, "*");
      } catch {}
      return;
    }
    const overlay = ensureOverlay();
    let flash = document.getElementById("__duet_flash");
    if (!flash) {
      flash = document.createElement("div");
      flash.id = "__duet_flash";
      flash.style.cssText = `
        background: linear-gradient(135deg, rgba(15,13,24,0.94), rgba(8,7,13,0.96));
        backdrop-filter: blur(16px) saturate(1.4);
        -webkit-backdrop-filter: blur(16px) saturate(1.4);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 14px;
        color: #f4f1ea;
        font-size: 13px; font-weight: 600;
        padding: 10px 14px;
        display: flex; align-items: center; gap: 10px;
        pointer-events: none;
        box-shadow: 0 14px 32px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04) inset;
        transition: opacity 0.4s ease, transform 0.4s ease;
        opacity: 0; transform: translateY(10px) scale(0.96);
      `;
      overlay.insertBefore(flash, overlay.firstChild);
    }
    const isPlay = action === "play";
    const accent = isPlay ? "#5ee2a0" : "#ffc89a";
    const glyph = isPlay
      ? '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 1.5v9l8-4.5L3 1.5z" fill="currentColor"/></svg>'
      : '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="2.5" y="1.5" width="2.5" height="9" rx="0.7" fill="currentColor"/><rect x="7" y="1.5" width="2.5" height="9" rx="0.7" fill="currentColor"/></svg>';
    const who = partnerName || "Partner";
    const label = customLabel || (isPlay ? `${who} played` : `${who} paused`);
    flash.innerHTML = `
      <span style="display:grid;place-items:center;width:22px;height:22px;border-radius:7px;background:${accent}1a;color:${accent};box-shadow:0 0 0 1px ${accent}33 inset">${glyph}</span>
      <span>${label}</span>
    `;
    flash.style.opacity = "1";
    flash.style.transform = "translateY(0) scale(1)";
    clearTimeout(flash.__t);
    flash.__t = setTimeout(() => {
      flash.style.opacity = "0";
      flash.style.transform = "translateY(10px) scale(0.96)";
    }, 2500);
  }

  // ── Floating reactions & Chat ──────────────────────────────
  function spawnReaction(emoji) {
    const node = document.createElement("div");
    node.textContent = emoji;
    
    // Distinguish simple emojis from chat messages
    const isText = /[a-zA-Z0-9]/.test(emoji) || emoji.length > 4;

    if (isText) {
      const topY = 10 + Math.random() * 65; // 10%–75% down the screen
      // Cap length and adapt font-size so very long messages still fit on one line
      const trimmed = emoji.slice(0, 140);
      node.textContent = trimmed;
      const len = trimmed.length;
      const fontSize = len < 30 ? 26 : len < 70 ? 20 : 16;
      node.style.cssText = `
        position: fixed; right: -100%; top: ${topY}%; z-index: 2147483647;
        max-width: 70vw;
        font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
        font-size: ${fontSize}px; font-weight: 700; color: #fff;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.85),
                     -1px -1px 0 #000, 1px -1px 0 #000,
                     -1px 1px 0 #000, 1px 1px 0 #000;
        pointer-events: none; white-space: nowrap;
        animation: __pp_slide 9s linear forwards;
      `;
    } else {
      const startX = 30 + Math.random() * 60; // 30%–90%
      node.style.cssText = `
        position: fixed; left: ${startX}%; bottom: 80px; font-size: 48px;
        z-index: 2147483647; pointer-events: none;
        filter: drop-shadow(0 4px 14px rgba(0,0,0,0.45));
        animation: __pp_float 2.6s cubic-bezier(.2,.7,.3,1) forwards; opacity: 0;
      `;
    }
    
    (document.documentElement || document.body).appendChild(node);
    setTimeout(() => node.remove(), isText ? 8500 : 2700);
  }

  // Inject keyframes once
  (function injectReactionStyles() {
    if (document.getElementById("__pp_styles")) return;
    const s = document.createElement("style");
    s.id = "__pp_styles";
    s.textContent = `
      @keyframes __pp_float {
        0%   { opacity: 0; transform: translateY(20px)  scale(0.6) rotate(-8deg); }
        15%  { opacity: 1; transform: translateY(0)     scale(1.1) rotate(2deg); }
        30%  {              transform: translateY(-30px) scale(1)   rotate(-2deg); }
        100% { opacity: 0; transform: translateY(-220px) scale(0.9) rotate(6deg); }
      }
      @keyframes __pp_slide {
        0%   { transform: translateX(0); }
        100% { transform: translateX(-150vw); }
      }
    `;
    (document.head || document.documentElement).appendChild(s);
  })();

  let currentDriftStatus = "waiting"; // waiting, sync, warning, out_of_sync, mismatch
  
  // ── Message Listener ───────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "REMOTE_SYNC") {
      applySync(message.state, message.serverNow);
    } else if (message.type === "CONNECTION_STATUS") {
      const wasConnected = connected;
      connected = !!message.connected;
      peerCount = message.peerCount || 0;
      updateOverlay();
      if (connected && !wasConnected) startTabInfoTimer();
      if (!connected && tabInfoTimer) { clearInterval(tabInfoTimer); tabInfoTimer = null; }
      if (connected) sendTabInfo();
    } else if (message.type === "SHOW_REACTION") {
      spawnReaction(message.emoji);
    } else if (message.type === "SYNC_STATUS") {
      // Cache partner's display name for flash labels.
      const prevName = partnerName;
      if (message.partner && typeof message.partner.name === "string") {
        partnerName = message.partner.name;
      } else if (!message.partner) {
        partnerName = "";
      }
      if (message.partner && typeof message.partner.emoji === "string") {
        partnerEmoji = message.partner.emoji;
      } else if (!message.partner) {
        partnerEmoji = "";
      }
      if (partnerName !== prevName) refreshSyncBtnLabel();
      // Don't claim any sync state until we actually have live data on both sides.
      // A partner record with just `{userId}` and no currentTime/url means they
      // haven't published a video yet — we should say "waiting", not "in sync".
      // 15s window matches the popup's three-state freshness model. Chrome
      // throttles background tabs, so anything tighter flickered to "waiting"
      // mid-watch on real connections.
      const hasLiveData = (m) =>
        m && typeof m.currentTime === "number" && typeof m.url === "string" &&
        typeof m.lastSeen === "number" && (message.serverNow - m.lastSeen) < 15000;

      if (peerCount < 2 || !hasLiveData(message.partner) || !hasLiveData(message.mine)) {
        currentDriftStatus = "waiting";
        updateOverlay();
        return;
      }

      const norm = u => { try { const url = new URL(u); return url.origin + url.pathname + url.search; } catch { return u; } };
      const mismatch = norm(message.mine.url) !== norm(message.partner.url);

      if (mismatch) {
        currentDriftStatus = "mismatch";
      } else if (message.mine.paused || message.partner.paused) {
        const drift = Math.abs((message.mine.currentTime || 0) - (message.partner.currentTime || 0));
        currentDriftStatus = drift > 1.5 ? "out_of_sync" : "sync";
      } else {
        const project = m => (m.currentTime || 0) + Math.max(0, (message.serverNow - m.lastSeen) / 1000);
        const drift = Math.abs(project(message.mine) - project(message.partner));

        if (drift > 2.0) currentDriftStatus = "out_of_sync";
        else if (drift > 0.8) currentDriftStatus = "warning";
        else currentDriftStatus = "sync";
      }
      updateOverlay();
      
    } else if (message.type === "GET_VIDEO_SNAPSHOT") {
      // Synchronous-ish: respond with current video state for sync-to-me
      if (!video) video = findVideo();
      if (!video) { sendResponse({ hasVideo: false }); return true; }
      sendResponse({
        hasVideo: true,
        currentTime: video.currentTime,
        playbackRate: video.playbackRate,
        paused: video.paused
      });
      return true;
    }
  });

  // ── Ad skipping (YouTube + yflix.to) ───────────────────────
  const host = location.hostname.replace(/^www\./, "");
  const isYouTube = /(^|\.)youtube\.com$/.test(host);
  const isYflix   = /(^|\.)yflix\.to$/.test(host);

  function showAdSkipFlash(label) {
    showFlash("play", label);
    // Override the icon to a "skip" glyph
    const flash = document.getElementById("__duet_flash");
    if (!flash) return;
    const icon = flash.querySelector("span");
    if (icon) icon.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 12 12" fill="none">' +
      '<path d="M2 1.5v9l6-4.5L2 1.5zM9 1.5h1.5v9H9z" fill="currentColor"/></svg>';
  }

  if (isYouTube) {
    let wasAd = false;
    ytAdTimer = setInterval(() => {
      if (!extAlive()) return;
      const player = document.querySelector(".html5-video-player");
      if (!player) return;
      const isAd = player.classList.contains("ad-showing") ||
                   player.classList.contains("ad-interrupting");
      adInProgress = isAd;

      if (isAd) {
        // Click the skip button if it's mounted
        const skip = player.querySelector(
          ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button"
        );
        if (skip) { try { skip.click(); } catch {} }

        // For unskippable ads: fast-forward the ad video to its end
        const ads = player.querySelectorAll("video");
        for (const v of ads) {
          if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.3) {
            try { v.currentTime = v.duration; } catch {}
          }
        }

        if (!wasAd) showAdSkipFlash("Skipped YouTube ad");
        wasAd = true;
      } else if (wasAd) {
        wasAd = false;
      }
    }, 400);
  }

  if (isYflix) {
    // 1. Popup-on-click ad blocking is now handled by yflix-main.js running in the MAIN world

    // 2. Hide common ad/banner DOM nodes
    const AD_SELECTORS = [
      'iframe[src*="ads"]', 'iframe[src*="ad."]', 'iframe[src*="exoclick"]',
      'iframe[src*="trafficjunky"]', 'iframe[src*="propeller"]', 'iframe[src*="popcash"]',
      'iframe[src*="adsterra"]', 'iframe[src*="hilltopads"]', 'iframe[src*="adnxs"]',
      'iframe[src*="doubleclick"]', 'iframe[src*="googlesyndication"]',
      '[id*="banner"]', '[id*="adslot"]', '[class*="banner-ad"]',
      '.ads', '.advertisement', '#ads', '.ad-container',
      'div[id^="ad_"]', 'div[class^="ad_"]', 'div[class*=" ad-"]'
    ];

    const HIDE_RULE = `${AD_SELECTORS.join(",")} { display:none !important; visibility:hidden !important; opacity:0 !important; pointer-events:none !important; height:0 !important; width:0 !important; }`;

    const styleEl = document.createElement("style");
    styleEl.id = "__duet_adhide";
    styleEl.textContent = HIDE_RULE;
    (document.head || document.documentElement).appendChild(styleEl);

    // 3. Intercept clicks on links that look like trackers/popunders
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a");
      if (!a) return;
      const href = a.href || "";
      const looksBad =
        a.target === "_blank" &&
        /(?:^|[\/.])(pop|ads?|click|redirect|track|out|go)\b/i.test(new URL(href, location.href).hostname + new URL(href, location.href).pathname);
      // Also block javascript: links that often trigger window.open
      if (looksBad || /^javascript:/i.test(href)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    }, true);

    // 4. Periodically try the skip button used by JW/Plyr-style players
    yflixSkipTimer = setInterval(() => {
      if (!extAlive()) return;
      const skip = document.querySelector(
        '.jw-skip, .jw-button-skip, .skip-ad, [class*="skip-ad" i], [aria-label*="skip" i]'
      );
      if (skip && skip.offsetParent !== null) {
        const now = Date.now();
        if (now - (skip.__pp_last_click || 0) < 3000) return;
        skip.__pp_last_click = now;
        try { skip.click(); } catch {}
      }
    }, 600);

    console.log("[Duet] yflix.to ad guard active.");
  }

  // ── Initial status fetch ───────────────────────────────────
  safeSend({ type: "GET_STATUS" }).then((status) => {
    if (status?.currentRoom) {
      connected = true;
      peerCount = status.peerCount || 1;
      updateOverlay();
      startTabInfoTimer();
      sendTabInfo();
    }
  });
})();
