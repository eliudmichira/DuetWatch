// ============================================================
//  Duet — Background Service Worker
// ============================================================

importScripts(
  "vendor/firebase-app-compat.js",
  "vendor/firebase-database-compat.js"
);

// ── Hardcoded Firebase Config ───────────────────────────────
const FIREBASE_CONFIG = {
  apiKey:            "AIzaSyAMT9lZ_CJqMewsosu6yKJ6UcR8nTGSPeA",
  authDomain:        "pausepal-a4d71.firebaseapp.com",
  databaseURL:       "https://pausepal-a4d71-default-rtdb.firebaseio.com",
  projectId:         "pausepal-a4d71",
  messagingSenderId: "870295332520",
  appId:             "1:870295332520:web:caf80b137bc8b50f5f449d"
};

// ── State ───────────────────────────────────────────────────
let db = null;
let currentRoom = null;
let myUserId = null;
let roomRef = null;
let presenceRef = null;
let metaRef = null;
let reactionsRef = null;

let stateListenerOff = null;
let presenceListenerOff = null;
let metaListenerOff = null;
let togListenerOff = null;
let reactionsListenerOff = null;

let serverTimeOffset = 0;
let partnerMeta = null;       // last meta we saw from the partner
let myLastTabInfo = null;     // last meta we wrote ourselves
let lastPeerCount = 0;        // for detecting 1→2 transition (auto-resync trigger)
let togetherInfo = { since: null, total: 0 };  // co-watch timer state

let primaryTabId = null;      // the single active video tab we are tracking
let lastTabInfoTime = 0;      // when we last heard from the primary tab

// ── Diagnostics ─────────────────────────────────────────────
// Surfaces silent failures (rule rejections, missing tab, etc.) to the popup
// so the user can see *why* things aren't working without opening devtools.
const diag = {
  lastWriteOk:    { op: null, at: 0 },
  lastWriteErr:   { op: null, at: 0, message: null, hint: null },
  lastPartnerAt:  0,
  myUserId:       null,
  partnerUserId:  null,
  primaryTabId:   null,
  peerCount:      0,
  ruleHints:      []
};

function recordOk(op) {
  diag.lastWriteOk = { op, at: Date.now() };
}
function recordErr(op, err) {
  const message = err?.message || String(err);
  const hint = explainFirebaseError(op, message);
  diag.lastWriteErr = { op, at: Date.now(), message, hint };
  if (hint && !diag.ruleHints.includes(hint)) diag.ruleHints.push(hint);
}

// Translate Firebase errors into plain-English fixes the user can act on.
function explainFirebaseError(op, message) {
  if (!message) return null;
  if (message.includes("PERMISSION_DENIED")) {
    if (op === "pushSyncEvent")
      return "Firebase rejected a sync write — your DB rules likely don't allow the `force` field. Re-paste the latest rules from the README and Publish.";
    if (op === "pushTabInfo")
      return "Firebase rejected the tab-info write. Your DB rules may be blocking writes outside `state`. Re-paste the rules from the README.";
    if (op === "pushReaction")
      return "Firebase rejected a reaction. Same root cause — re-paste the rules from the README.";
    return "Firebase rejected the write. Check your Realtime Database rules.";
  }
  if (message.includes("Network") || message.includes("offline"))
    return "Network looks offline. Reconnect and the sync will catch up.";
  return null;
}

// ── Firebase Setup ──────────────────────────────────────────
async function initFirebase() {
  if (db) return true;
  await Promise.all(firebase.apps.map(app => app.delete()));
  firebase.initializeApp(FIREBASE_CONFIG);
  db = firebase.database();

  db.ref(".info/serverTimeOffset").on("value", (snap) => {
    serverTimeOffset = snap.val() || 0;
  });
  return true;
}

const serverNow = () => Date.now() + serverTimeOffset;

// ── Helpers ─────────────────────────────────────────────────
const ROOM_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function generateRoomCode() {
  let code = "";
  for (let i = 0; i < 6; i++) code += ROOM_ALPHABET[Math.floor(Math.random() * ROOM_ALPHABET.length)];
  return code;
}
const generateUserId = () => "user_" + Math.random().toString(36).slice(2, 10);

// ── Room Management ─────────────────────────────────────────
async function createRoom() {
  await initFirebase();

  const roomCode = generateRoomCode();
  myUserId = generateUserId();

  setRoomRefs(roomCode);

  await roomRef.set({
    state: {
      action: "pause", currentTime: 0, updatedBy: myUserId,
      serverTime: firebase.database.ServerValue.TIMESTAMP
    },
    host: myUserId,
    created: firebase.database.ServerValue.TIMESTAMP
  });

  await presenceRef.set({ joined: firebase.database.ServerValue.TIMESTAMP });
  presenceRef.onDisconnect().remove();
  metaRef.onDisconnect().remove();

  currentRoom = roomCode;
  attachListeners(roomCode);

  await chrome.storage.local.set({ currentRoom: roomCode, myUserId });
  validateRules().catch(() => {});
  return { roomCode, myUserId, peerCount: 1 };
}

async function joinRoom(roomCode) {
  await doBootstrap();
  roomCode = roomCode.toUpperCase().trim();

  const snap = await db.ref(`rooms/${roomCode}`).get();
  if (!snap.exists()) return { error: "Room not found. Check the code and try again." };

  // Note: We removed the strict 'memberCount >= 2' rejection here.
  // If the service worker crashes, Firebase can leave a 'ghost' connection for ~60s.
  // We want to allow the user to rejoin their own room without being blocked by their own ghost!

  myUserId = generateUserId();
  setRoomRefs(roomCode);

  await presenceRef.set({ joined: firebase.database.ServerValue.TIMESTAMP });
  presenceRef.onDisconnect().remove();
  metaRef.onDisconnect().remove();

  currentRoom = roomCode;
  attachListeners(roomCode);

  await chrome.storage.local.set({ currentRoom: roomCode, myUserId });
  validateRules().catch(() => {});
  return { roomCode, myUserId, joined: true };
}

function setRoomRefs(roomCode) {
  roomRef      = db.ref(`rooms/${roomCode}`);
  presenceRef  = db.ref(`presence/${roomCode}/${myUserId}`);
  metaRef      = db.ref(`rooms/${roomCode}/meta/${myUserId}`);
  reactionsRef = db.ref(`rooms/${roomCode}/reactions`);
}

async function leaveRoom() {
  try { if (presenceRef) await presenceRef.remove(); } catch {}
  try { if (metaRef)     await metaRef.remove();     } catch {}
  detachListeners();
  roomRef = presenceRef = metaRef = reactionsRef = null;
  currentRoom = myUserId = null;
  partnerMeta = null;
  myLastTabInfo = null;
  lastPeerCount = 0;
  togetherInfo = { since: null, total: 0 };
  diag.lastWriteOk    = { op: null, at: 0 };
  diag.lastWriteErr   = { op: null, at: 0, message: null, hint: null };
  diag.lastPartnerAt  = 0;
  diag.partnerUserId  = null;
  diag.peerCount      = 0;
  diag.ruleHints      = [];
  rulesValidated      = false;
  await chrome.storage.local.remove(["currentRoom", "myUserId"]);
  broadcastConnection(false, 0);
  return { left: true };
}

// ── Listeners ───────────────────────────────────────────────
function attachListeners(roomCode) {
  detachListeners();

  // Video state
  const stateRef = db.ref(`rooms/${roomCode}/state`);
  const stateHandler = stateRef.on("value", (snap) => {
    const state = snap.val();
    if (!state || state.updatedBy === myUserId) return;
    broadcastToVideoTabs({ type: "REMOTE_SYNC", state, serverNow: serverNow() });
  });
  stateListenerOff = () => stateRef.off("value", stateHandler);

  // Presence
  const presRef = db.ref(`presence/${roomCode}`);
  const presHandler = presRef.on("value", (snap) => {
    const count = snap.exists() ? Object.keys(snap.val()).length : 0;
    handlePeerCountChange(count);
    broadcastConnection(true, count);
  });
  presenceListenerOff = () => presRef.off("value", presHandler);

  // Watch-time counter (shared across both clients)
  const togRef = db.ref(`rooms/${roomCode}/together`);
  const togHandler = togRef.on("value", (snap) => {
    togetherInfo = snap.val() || { since: null, total: 0 };
    chrome.runtime.sendMessage({ type: "POPUP_TOGETHER", together: togetherInfo, serverNow: serverNow() }).catch(() => {});
  });
  togListenerOff = () => togRef.off("value", togHandler);

  // Partner metadata (what they're watching)
  const meta = db.ref(`rooms/${roomCode}/meta`);
  const metaHandler = meta.on("value", (snap) => {
    const all = snap.val() || {};
    const partners = Object.entries(all)
      .filter(([uid]) => uid !== myUserId)
      .map(p => ({ userId: p[0], ...p[1] }))
      .sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));

    partnerMeta = partners[0] || null;
    if (partnerMeta) {
      diag.lastPartnerAt = Date.now();
      diag.partnerUserId = partnerMeta.userId;
    } else {
      diag.partnerUserId = null;
    }
    broadcastPartnerMeta();
  });
  metaListenerOff = () => meta.off("value", metaHandler);

  // Reactions
  const reacts = db.ref(`rooms/${roomCode}/reactions`);
  const reactsHandler = reacts.on("child_added", (snap) => {
    const r = snap.val();
    if (!r || r.from === myUserId) return;
    // Drop reactions that arrived from before we joined
    if (Date.now() - r.ts > 8000) return;
    broadcastToVideoTabs({ type: "SHOW_REACTION", emoji: r.emoji });
  });
  reactionsListenerOff = () => reacts.off("child_added", reactsHandler);
}

function detachListeners() {
  for (const off of [stateListenerOff, presenceListenerOff, metaListenerOff, togListenerOff, reactionsListenerOff]) {
    try { off?.(); } catch {}
  }
  stateListenerOff = presenceListenerOff = metaListenerOff = togListenerOff = reactionsListenerOff = null;
}

// ── Peer-count transitions (auto-resync + together-timer) ──
function handlePeerCountChange(newCount) {
  const prev = lastPeerCount;
  lastPeerCount = newCount;
  diag.peerCount = newCount;

  // Partner just arrived → push my current state so they snap to me
  // (only the *existing* user fires this; freshly-joined users had prev=0)
  if (prev === 1 && newCount === 2) {
    setTimeout(() => { syncToMe().catch(() => {}); }, 1200);
  }

  // Together timer: start when room first reaches 2; freeze when it drops below 2
  const togRef = db.ref(`rooms/${currentRoom}/together`);
  if (newCount >= 2 && prev < 2) {
    // Set "since" only if not already set (race-safe via transaction)
    togRef.transaction((cur) => {
      const t = cur || { since: null, total: 0 };
      if (!t.since) t.since = firebase.database.ServerValue.TIMESTAMP;
      return t;
    });
  } else if (newCount < 2 && prev >= 2) {
    // Accumulate elapsed into total, clear "since"
    togRef.transaction((cur) => {
      const t = cur || { since: null, total: 0 };
      if (t.since && typeof t.since === "number") {
        const elapsed = Math.max(0, (serverNow() - t.since) / 1000);
        t.total = (t.total || 0) + elapsed;
      }
      t.since = null;
      return t;
    });
  }
}

// ── Pushes to Firebase ──────────────────────────────────────
// Returns { ok } or { error, code }. The caller decides whether to surface.
async function pushSyncEvent(state, opts = {}) {
  if (!roomRef || !myUserId) return { error: "Not in a room." };
  // Only include `force` when true — RTDB rules whitelist state keys; `force: false`
  // still counts as an extra key and rejects the whole write with $other: false.
  const payload = {
    ...state,
    updatedBy: myUserId,
    serverTime: firebase.database.ServerValue.TIMESTAMP
  };
  if (opts.force) payload.force = true;
  try {
    await roomRef.child("state").set(payload);
    recordOk("pushSyncEvent");
    return { ok: true };
  } catch (err) {
    const msg = err?.message || String(err);
    const denied = /PERMISSION_DENIED/i.test(msg);
    if (denied && payload.force) {
      delete payload.force;
      try {
        await roomRef.child("state").set(payload);
        recordOk("pushSyncEvent");
        // Surface the rule-mismatch as a one-time hint, not an error
        const hint = "Your Firebase rules don't allow `force`. Sync still works (via drift threshold), but add the `force` rule from the README for instant snaps.";
        if (!diag.ruleHints.includes(hint)) diag.ruleHints.push(hint);
        return { ok: true, degraded: "no-force-rule" };
      } catch (err2) {
        recordErr("pushSyncEvent", err2);
        console.warn("[Duet] pushSyncEvent retry:", err2?.message || err2);
        return { error: "Firebase rejected the write. Check your RTDB rules.", code: "permission_denied" };
      }
    }
    recordErr("pushSyncEvent", err);
    console.warn("[Duet] pushSyncEvent:", msg);
    return { error: denied ? "Firebase rejected the write." : "Network error." , code: denied ? "permission_denied" : "network" };
  }
}

async function pushTabInfo(info) {
  if (!metaRef) return;
  myLastTabInfo = { ...info, lastSeen: serverNow() };
  try {
    await metaRef.set({
      ...info,
      lastSeen: firebase.database.ServerValue.TIMESTAMP
    });
    recordOk("pushTabInfo");
  } catch (err) {
    recordErr("pushTabInfo", err);
  }
}

async function pushReaction(emoji) {
  if (!reactionsRef || !myUserId) return;
  const ref = reactionsRef.push();
  try {
    await ref.set({ emoji, from: myUserId, ts: Date.now() });
    recordOk("pushReaction");
    setTimeout(() => ref.remove().catch(() => {}), 6000);
  } catch (err) {
    recordErr("pushReaction", err);
  }
}

// Ask every frame in a tab and return the first response with a video.
async function getSnapshotFromAnyFrame(tabId) {
  let frames = [];
  try {
    frames = (await chrome.webNavigation.getAllFrames({ tabId })) || [];
  } catch {}
  const ids = frames.length ? frames.map(f => f.frameId) : [0];
  const results = await Promise.all(ids.map(frameId =>
    chrome.tabs.sendMessage(tabId, { type: "GET_VIDEO_SNAPSHOT" }, { frameId })
      .then(r => ({ frameId, r })).catch(() => null)
  ));
  return results.find(x => x && x.r?.hasVideo) || null;
}

// ── Rule validation ─────────────────────────────────────────
// Probes the `force` field on `state` to detect a common rule/code mismatch
// *before* the user hits a real sync failure. Only safe when alone in the room
// (a partner's listener would fire on the probe and trigger a phantom sync).
let rulesValidated = false;
async function validateRules() {
  if (rulesValidated || !roomRef || !myUserId) return;

  // Only probe when alone — otherwise the partner sees a state write and reacts.
  try {
    const presSnap = await db.ref(`presence/${currentRoom}`).get();
    const peers = presSnap.exists() ? Object.keys(presSnap.val()).length : 0;
    if (peers > 1) return;
  } catch { return; }

  const forceRef = roomRef.child("state/force");
  try {
    await forceRef.set(true);
    await forceRef.remove().catch(() => {});
    rulesValidated = true;
  } catch (err) {
    const msg = err?.message || String(err);
    if (/PERMISSION_DENIED/i.test(msg)) {
      const hint = "Your Firebase rules don't whitelist `force` — add the `force` line from the README under `state` and Publish. Sync still works via the drift fallback until then.";
      if (!diag.ruleHints.includes(hint)) diag.ruleHints.push(hint);
      rulesValidated = true; // don't keep probing; we have our answer
    } else {
      recordErr("validateRules", err);
    }
  }
}

// ── Force-sync to me ────────────────────────────────────────
// Asks the active video tab for its current state, then pushes with force=true.
async function syncToMe() {
  if (!roomRef) return { error: "Not in a room." };

  let targetTabId = primaryTabId;
  if (!targetTabId) {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    targetTabId = tabs[0]?.id;
  }
  if (!targetTabId) return { error: "No active tab." };

  const hit = await getSnapshotFromAnyFrame(targetTabId);
  if (!hit) return { error: "No video found in this tab." };
  const snapshot = hit.r;

  const result = await pushSyncEvent({
    action: snapshot.paused ? "pause" : "play",
    currentTime: snapshot.currentTime,
    playbackRate: snapshot.playbackRate
  }, { force: true });

  if (result?.error) return result;
  return { ok: true, degraded: result?.degraded, at: snapshot.currentTime };
}

async function sendToAllFrames(tabId, message) {
  let frames = [];
  try {
    frames = (await chrome.webNavigation.getAllFrames({ tabId })) || [];
  } catch {}
  if (!frames.length) {
    return chrome.tabs.sendMessage(tabId, message).catch(() => { throw new Error("no-tab"); });
  }
  await Promise.all(frames.map(f =>
    chrome.tabs.sendMessage(tabId, message, { frameId: f.frameId }).catch(() => {})
  ));
}

// ── Broadcasts to UI ────────────────────────────────────────
function broadcastToVideoTabs(message) {
  if (message.type === "REMOTE_SYNC" && primaryTabId) {
    // Prevent background tabs from acting on remote syncs.
    // Send to ALL frames so cross-origin embed iframes (yflix, etc.) receive it.
    sendToAllFrames(primaryTabId, message).catch(() => {
      primaryTabId = null; // Tab probably closed
    });
    return;
  }

  // General broadcasts (reactions, connection status) go to all video tabs
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (!tab.id) continue;
      sendToAllFrames(tab.id, message).catch(() => {});
    }
  });
}
function broadcastConnection(connected, peerCount) {
  broadcastToVideoTabs({ type: "CONNECTION_STATUS", connected, peerCount, room: currentRoom });
  chrome.runtime.sendMessage({ type: "POPUP_PEER_COUNT", peerCount }).catch(() => {});
}
function broadcastPartnerMeta() {
  chrome.runtime.sendMessage({ type: "POPUP_PARTNER_META", partner: partnerMeta, mine: myLastTabInfo }).catch(() => {});
  // Send status down to content scripts so the in-video badge knows the actual drift
  broadcastToVideoTabs({ type: "SYNC_STATUS", partner: partnerMeta, mine: myLastTabInfo, serverNow: serverNow() });
}

// ── Open partner's URL ──────────────────────────────────────
async function openPartnerVideo() {
  if (!partnerMeta?.url) return { error: "Partner hasn't shared a video yet." };
  
  // Try to redirect the exact tab we've been tracking, fallback to active tab
  let targetTabId = primaryTabId;
  if (!targetTabId) {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    targetTabId = tabs[0]?.id;
  }

  if (targetTabId) {
    await chrome.tabs.update(targetTabId, { url: partnerMeta.url });
  } else {
    await chrome.tabs.create({ url: partnerMeta.url });
  }
  return { ok: true };
}

// ── Message Router ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      await doBootstrap(); // Wait for session restore before processing ANY message

      switch (message.type) {
        case "CREATE_ROOM":   sendResponse(await createRoom()); break;
        case "JOIN_ROOM":     sendResponse(await joinRoom(message.roomCode)); break;
        case "LEAVE_ROOM":    sendResponse(await leaveRoom()); break;

        case "SYNC_EVENT":
          if (_sender.tab?.id) {
            primaryTabId = _sender.tab.id; // Manual interaction steals control
            diag.primaryTabId = primaryTabId;
          }
          await pushSyncEvent(message.state);
          sendResponse({ ok: true });
          break;

        case "TAB_INFO":
          if (_sender.tab?.id) {
            // Content script only sends TAB_INFO from the top frame, so per-tab
            // dedup is already implicit. Track which tab is the active video tab
            // so SYNC_TO_ME and OPEN_PARTNER_URL target the right place. Prefer
            // the tab whose video is currently playing; otherwise keep what we have.
            const incomingPlaying = !message.info.paused;
            const stale = (Date.now() - lastTabInfoTime) > 5000;
            if (!primaryTabId || incomingPlaying || stale) {
              primaryTabId = _sender.tab.id;
              diag.primaryTabId = primaryTabId;
            }
            lastTabInfoTime = Date.now();
            await pushTabInfo(message.info);
          }
          sendResponse({ ok: true });
          break;

        case "SEND_REACTION":
          await pushReaction(message.emoji);
          sendResponse({ ok: true });
          break;

        case "SYNC_TO_ME":
          sendResponse(await syncToMe());
          break;

        case "OPEN_PARTNER_URL":
          sendResponse(await openPartnerVideo());
          break;

        case "GET_STATUS": {
          let peerCount = 0;
          if (currentRoom && db) {
            const snap = await db.ref(`presence/${currentRoom}`).get();
            peerCount = snap.exists() ? Object.keys(snap.val()).length : 0;
          }
          diag.myUserId = myUserId;
          diag.peerCount = peerCount;
          sendResponse({
            currentRoom, myUserId,
            connected: !!currentRoom,
            peerCount,
            partner: partnerMeta,
            mine: myLastTabInfo,
            together: togetherInfo,
            serverNow: serverNow(),
            diag
          });
          break;
        }

        case "PING":
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ error: "Unknown message type" });
      }
    } catch (err) {
      console.error("[Duet] handler error:", err);
      sendResponse({ error: err?.message || String(err) });
    }
  })();
  return true;
});

// ── Bootstrap ───────────────────────────────────────────────
let bootstrapPromise = null;

function doBootstrap() {
  if (!bootstrapPromise) bootstrapPromise = bootstrapInner();
  return bootstrapPromise;
}

async function bootstrapInner() {
  await initFirebase();

  const stored = await chrome.storage.local.get(["currentRoom", "myUserId"]);
  if (!stored.currentRoom) return;

  const exists = (await db.ref(`rooms/${stored.currentRoom}`).get()).exists();
  if (!exists) {
    await chrome.storage.local.remove(["currentRoom", "myUserId"]);
    return;
  }

  currentRoom = stored.currentRoom;
  myUserId = stored.myUserId;
  setRoomRefs(currentRoom);
  await presenceRef.set({ joined: firebase.database.ServerValue.TIMESTAMP });
  presenceRef.onDisconnect().remove();
  metaRef.onDisconnect().remove();
  attachListeners(currentRoom);
  validateRules().catch(() => {});
  console.log(`[Duet] Restored session: room ${currentRoom}`);
}

chrome.runtime.onStartup.addListener(doBootstrap);
chrome.runtime.onInstalled.addListener(doBootstrap);
doBootstrap();
