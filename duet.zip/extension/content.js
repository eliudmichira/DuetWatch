// ============================================================
//  Duet — Content Script
// ============================================================

(function () {
  if (window.__duetInjected) return;
  window.__duetInjected = true;

  let video = null;
  let isApplyingRemote = false;
  let connected = false;
  let peerCount = 0;
  let lastSentSig = "";
  let lastSentAt = 0;
  let lastTabInfoAt = 0;
  let tabInfoTimer = null;
  let adInProgress = false;   // suppress sync while we're watching/skipping an ad
  let contextInvalid = false; // set true once the extension is reloaded/uninstalled

  // Returns true if the background is still reachable. If not, marks the page
  // as dead so periodic timers can self-terminate.
  function extAlive() {
    if (contextInvalid) return false;
    try {
      if (!chrome.runtime?.id) { contextInvalid = true; teardown(); return false; }
      return true;
    } catch {
      contextInvalid = true;
      teardown();
      return false;
    }
  }

  // Wrapper around chrome.runtime.sendMessage that never throws and never rejects.
  // (Raw sendMessage throws SYNCHRONOUSLY on "Extension context invalidated", so
  // .catch() alone isn't enough.)
  function safeSend(msg) {
    if (!extAlive()) return Promise.resolve(null);
    try {
      const p = chrome.runtime.sendMessage(msg);
      return p && typeof p.catch === "function" ? p.catch(() => null) : Promise.resolve(null);
    } catch {
      contextInvalid = true;
      teardown();
      return Promise.resolve(null);
    }
  }

  function teardown() {
    try { observer?.disconnect(); } catch {}
    if (tabInfoTimer)   { clearInterval(tabInfoTimer);   tabInfoTimer   = null; }
    if (ytAdTimer)      { clearInterval(ytAdTimer);      ytAdTimer      = null; }
    if (yflixSkipTimer) { clearInterval(yflixSkipTimer); yflixSkipTimer = null; }
    // Hide the badge — extension is gone, anything it claims is stale
    const badge = document.getElementById("__duet_badge");
    if (badge) badge.style.opacity = "0";
  }

  let ytAdTimer = null;
  let yflixSkipTimer = null;

  // ── Video Detection ────────────────────────────────────────
  function scoreVideo(v) {
    const r = v.getBoundingClientRect();
    const visible = r.width > 0 && r.height > 0 && getComputedStyle(v).visibility !== "hidden";
    if (!visible) return 0;
    const area = r.width * r.height;
    const ready = v.readyState >= 2 ? 1 : 0;
    return area + ready * 1_000_000;
  }
  function findVideo() {
    const videos = Array.from(document.querySelectorAll("video"));
    if (!videos.length) return null;
    let best = null, bestScore = 0;
    for (const v of videos) {
      const s = scoreVideo(v);
      if (s > bestScore) { best = v; bestScore = s; }
    }
    return best;
  }
  function attachListeners(v) {
    if (v.__duetAttached) {
      video = v; // just update pointer if already attached
      return;
    }
    v.__duetAttached = true;
    video = v;
    const guard = (fn) => () => { 
      if (video !== v) return; // Drop events from old hidden videos
      try { fn(); } catch { contextInvalid = true; teardown(); } 
    };
    v.addEventListener("play",       guard(() => { sendSync("play");  sendTabInfo(true); }));
    v.addEventListener("pause",      guard(() => { sendSync("pause"); sendTabInfo(true); }));
    v.addEventListener("seeked",     guard(() => { sendSync(v.paused ? "pause" : "play"); sendTabInfo(true); }));
    v.addEventListener("ratechange", guard(() => { sendSync(v.paused ? "pause" : "play"); sendTabInfo(true); }));
    v.addEventListener("waiting",    guard(() => { sendSync("pause"); safeSend({ type: "SEND_REACTION", emoji: "⏳ Buffering..." }); }));
    v.addEventListener("playing",    guard(() => { sendSync("play");  sendTabInfo(true); }));
    v.addEventListener("timeupdate", guard(() => { sendTabInfo(); }));
    console.log("[Duet] Attached to active video player.");
    updateOverlay();
    sendTabInfo(true); // immediately push our metadata
  }

  // Streaming sites often keep old video elements hidden in the DOM.
  // Polling continuously ensures we always lock onto the currently visible video.
  setInterval(() => {
    if (!extAlive()) return;
    const best = findVideo();
    if (best && best !== video) {
      attachListeners(best);
    }
  }, 1500);

  // ── Send local action ──────────────────────────────────────
  function sendSync(action) {
    if (isApplyingRemote || !connected || !video) return;
    if (adInProgress) return; // don't push ad-video timestamps to partner
    const sig = `${action}|${video.currentTime.toFixed(2)}`;
    const now = Date.now();
    if (sig === lastSentSig && now - lastSentAt < 250) return;
    lastSentSig = sig;
    lastSentAt = now;

    safeSend({
      type: "SYNC_EVENT",
      state: {
        action,
        currentTime: video.currentTime,
        playbackRate: video.playbackRate
      }
    });
  }

  // ── Apply Remote Sync ──────────────────────────────────────
  function applySync(state, serverNow) {
    if (!video) {
      video = findVideo();
      if (!video) return;
    }

    isApplyingRemote = true;

    let targetTime = state.currentTime;
    if (state.action === "play" && typeof state.serverTime === "number" && typeof serverNow === "number") {
      const elapsed = Math.max(0, (serverNow - state.serverTime) / 1000);
      targetTime = state.currentTime + elapsed;
    }

    // Force-syncs always seek; normal updates only seek when drifting > 1s
    const driftThreshold = state.force ? 0 : 1.0;
    if (Math.abs(video.currentTime - targetTime) > driftThreshold) {
      try { video.currentTime = targetTime; } catch {}
    }

    if (state.playbackRate && Math.abs(video.playbackRate - state.playbackRate) > 0.01) {
      try { video.playbackRate = state.playbackRate; } catch {}
    }

    if (state.action === "play" && video.paused) {
      video.play().catch(() => showFlash("play", "Click the video to start (autoplay blocked)"));
    } else if (state.action === "pause" && !video.paused) {
      video.pause();
    }

    showFlash(state.action, state.force ? "Partner re-synced you" : null);

    setTimeout(() => { isApplyingRemote = false; }, 400);
  }

  // ── Tab metadata (what am I watching) ──────────────────────
  function getVideoTitle() {
    // YouTube-specific
    const yt = document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.title.ytd-video-primary-info-renderer");
    if (yt?.textContent?.trim()) return yt.textContent.trim();
    // OpenGraph
    const og = document.querySelector('meta[property="og:title"]')?.content;
    if (og) return og;
    return document.title;
  }

  // Only the top frame publishes tab metadata. Iframes (YouTube recommendations,
  // ad slots, sidecar players, etc.) used to spam TAB_INFO with the same tab.id
  // and overwrite the real player's metadata in Firebase, which made the partner
  // card render with empty/zero progress. If the actual player is in an iframe,
  // we defer to the top frame which still has access to the iframe's own video
  // via the page's DOM (or, for cross-origin iframes, to the iframe's <video>
  // tag scored by `findVideo()`).
  const isTopFrame = (() => {
    try { return window.top === window.self; } catch { return false; }
  })();

  function sendTabInfo(force = false) {
    if (!connected || !video) return;
    // Only frames with a real, loaded video may publish metadata.
    // This replaces an older `isTopFrame` gate that broke on sites
    // (yflix.to, etc.) where the player lives in a cross-origin iframe.
    // Empty ad/sidecar iframes have duration === 0 and are filtered here.
    if (!isTopFrame && !(isFinite(video.duration) && video.duration > 0)) return;
    const now = Date.now();
    if (!force && now - lastTabInfoAt < 1000) return;
    lastTabInfoAt = now;

    const info = {
      url: location.href,
      hostname: location.hostname.replace(/^www\./, ""),
      pageTitle: document.title,
      videoTitle: getVideoTitle(),
      duration: isFinite(video.duration) ? video.duration : 0,
      currentTime: video.currentTime,
      paused: video.paused
    };
    safeSend({ type: "TAB_INFO", info });
  }

  function startTabInfoTimer() {
    if (tabInfoTimer) clearInterval(tabInfoTimer);
    tabInfoTimer = setInterval(sendTabInfo, 1000);
  }
  document.addEventListener("visibilitychange", sendTabInfo);

  // ── Visual Feedback (overlay + flash) ──────────────────────
  function ensureOverlay() {
    let overlay = document.getElementById("__duet_overlay");
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "__duet_overlay";
    overlay.style.cssText = `
      position: fixed; bottom: 22px; right: 22px; z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Inter', sans-serif;
      pointer-events: none; display: flex; flex-direction: column;
      align-items: flex-end; gap: 8px;
    `;
    (document.documentElement || document.body).appendChild(overlay);
    return overlay;
  }

  function updateOverlay() {
    const overlay = ensureOverlay();
    let badge = document.getElementById("__duet_badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.id = "__duet_badge";
      badge.style.cssText = `
        position: relative;
        background: linear-gradient(135deg, rgba(15,13,24,0.92), rgba(8,7,13,0.94));
        backdrop-filter: blur(16px) saturate(1.4);
        -webkit-backdrop-filter: blur(16px) saturate(1.4);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 16px;
        color: #f4f1ea; font-size: 11.5px; font-weight: 600; letter-spacing: 0.01em;
        box-shadow: 0 10px 28px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.04) inset;
        transition: opacity 0.35s, transform 0.35s;
        opacity: 0; transform: translateY(6px);
        display: flex; flex-direction: column; overflow: hidden; pointer-events: auto;
      `;
      
      const topBar = document.createElement("div");
      topBar.id = "__pp_topbar";
      topBar.style.cssText = "display: flex; align-items: center; gap: 8px; padding: 7px 14px 7px 11px; cursor: pointer;";
      badge.appendChild(topBar);

      const controls = document.createElement("div");
      controls.id = "__pp_controls";
      controls.style.cssText = "display: none; flex-direction: column; gap: 8px; padding: 0 14px 12px 14px;";
      
      controls.innerHTML = `
        <div style="height: 1px; background: rgba(255,255,255,0.1); width: 100%; margin-bottom: 2px;"></div>
        <button id="__pp_sync_btn" style="background: rgba(255,255,255,0.1); border: none; color: white; border-radius: 6px; padding: 6px; font-weight: 600; cursor: pointer; transition: background 0.2s; font-size: 11px;">Sync Partner to Me</button>
        <div style="display: flex; gap: 6px; justify-content: space-between;">
          ${['😂', '😮', '💖', '😭'].map(e => `<button class="__pp_re_btn" style="background: rgba(255,255,255,0.05); border: none; border-radius: 6px; cursor: pointer; font-size: 15px; padding: 4px 6px; transition: background 0.2s;">${e}</button>`).join('')}
        </div>
      `;
      badge.appendChild(controls);

      // Interactions
      badge.addEventListener('mouseenter', () => { if(connected) controls.style.display = 'flex'; });
      badge.addEventListener('mouseleave', () => { controls.style.display = 'none'; });

      const syncBtn = controls.querySelector('#__pp_sync_btn');
      syncBtn.addEventListener('mouseenter', () => syncBtn.style.background = 'rgba(255,255,255,0.2)');
      syncBtn.addEventListener('mouseleave', () => syncBtn.style.background = 'rgba(255,255,255,0.1)');
      syncBtn.addEventListener('click', () => {
        safeSend({ type: "SYNC_TO_ME" });
        showFlash("play", "Syncing partner to you...");
      });

      controls.querySelectorAll('.__pp_re_btn').forEach(btn => {
        btn.addEventListener('mouseenter', () => btn.style.background = 'rgba(255,255,255,0.15)');
        btn.addEventListener('mouseleave', () => btn.style.background = 'rgba(255,255,255,0.05)');
        btn.addEventListener('click', (e) => {
          safeSend({ type: "SEND_REACTION", emoji: e.target.textContent });
          spawnReaction(e.target.textContent); // Show locally
        });
      });

      overlay.appendChild(badge);
    }
    
    if (connected) {
      let color = "#ffc89a";
      let text = "waiting for partner";
      
      if (peerCount >= 2) {
        if (currentDriftStatus === "sync") { color = "#5ee2a0"; text = "in sync"; }
        else if (currentDriftStatus === "warning") { color = "#fcd34d"; text = "slight delay"; }
        else if (currentDriftStatus === "out_of_sync") { color = "#ef4444"; text = "out of sync"; }
        else if (currentDriftStatus === "mismatch") { color = "#ef4444"; text = "different video"; }
        else { color = "#ffc89a"; text = "waiting for video"; }
      }

      document.getElementById("__pp_topbar").innerHTML = `
        <span style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 8px ${color}, 0 0 0 3px ${color}1f;display:inline-block;transition:all 0.3s;"></span>
        <span style="background:linear-gradient(110deg,#ffc89a,#f472b6,#8b5cf6);-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:700">Duet</span>
        <span style="color:rgba(244,241,234,0.55);font-weight:500">·</span>
        <span style="color:rgba(244,241,234,0.85);transition:color 0.3s;">${text}</span>
      `;
      badge.style.opacity = "1";
      badge.style.transform = "translateY(0)";
    } else {
      badge.style.opacity = "0";
      badge.style.transform = "translateY(6px)";
      document.getElementById("__pp_controls").style.display = 'none';
    }
  }

  function showFlash(action, customLabel) {
    const overlay = ensureOverlay();
    let flash = document.getElementById("__duet_flash");
    if (!flash) {
      flash = document.createElement("div");
      flash.id = "__duet_flash";
      flash.style.cssText = `
        background: linear-gradient(135deg, rgba(15,13,24,0.94), rgba(8,7,13,0.96));
        backdrop-filter: blur(16px) saturate(1.4);
        -webkit-backdrop-filter: blur(16px) saturate(1.4);
        border: 1px solid rgba(255,255,255,0.10);
        border-radius: 14px;
        color: #f4f1ea;
        font-size: 13px; font-weight: 600;
        padding: 10px 14px;
        display: flex; align-items: center; gap: 10px;
        pointer-events: none;
        box-shadow: 0 14px 32px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04) inset;
        transition: opacity 0.4s ease, transform 0.4s ease;
        opacity: 0; transform: translateY(10px) scale(0.96);
      `;
      overlay.insertBefore(flash, overlay.firstChild);
    }
    const isPlay = action === "play";
    const accent = isPlay ? "#5ee2a0" : "#ffc89a";
    const glyph = isPlay
      ? '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 1.5v9l8-4.5L3 1.5z" fill="currentColor"/></svg>'
      : '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="2.5" y="1.5" width="2.5" height="9" rx="0.7" fill="currentColor"/><rect x="7" y="1.5" width="2.5" height="9" rx="0.7" fill="currentColor"/></svg>';
    const label = customLabel || (isPlay ? "Partner played" : "Partner paused");
    flash.innerHTML = `
      <span style="display:grid;place-items:center;width:22px;height:22px;border-radius:7px;background:${accent}1a;color:${accent};box-shadow:0 0 0 1px ${accent}33 inset">${glyph}</span>
      <span>${label}</span>
    `;
    flash.style.opacity = "1";
    flash.style.transform = "translateY(0) scale(1)";
    clearTimeout(flash.__t);
    flash.__t = setTimeout(() => {
      flash.style.opacity = "0";
      flash.style.transform = "translateY(10px) scale(0.96)";
    }, 2500);
  }

  // ── Floating reactions & Chat ──────────────────────────────
  function spawnReaction(emoji) {
    const node = document.createElement("div");
    node.textContent = emoji;
    
    // Distinguish simple emojis from chat messages
    const isText = /[a-zA-Z0-9]/.test(emoji) || emoji.length > 4;

    if (isText) {
      const topY = 10 + Math.random() * 65; // 10%–75% down the screen
      // Cap length and adapt font-size so very long messages still fit on one line
      const trimmed = emoji.slice(0, 140);
      node.textContent = trimmed;
      const len = trimmed.length;
      const fontSize = len < 30 ? 26 : len < 70 ? 20 : 16;
      node.style.cssText = `
        position: fixed; right: -100%; top: ${topY}%; z-index: 2147483647;
        max-width: 70vw;
        font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
        font-size: ${fontSize}px; font-weight: 700; color: #fff;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.85),
                     -1px -1px 0 #000, 1px -1px 0 #000,
                     -1px 1px 0 #000, 1px 1px 0 #000;
        pointer-events: none; white-space: nowrap;
        animation: __pp_slide 9s linear forwards;
      `;
    } else {
      const startX = 30 + Math.random() * 60; // 30%–90%
      node.style.cssText = `
        position: fixed; left: ${startX}%; bottom: 80px; font-size: 48px;
        z-index: 2147483647; pointer-events: none;
        filter: drop-shadow(0 4px 14px rgba(0,0,0,0.45));
        animation: __pp_float 2.6s cubic-bezier(.2,.7,.3,1) forwards; opacity: 0;
      `;
    }
    
    (document.documentElement || document.body).appendChild(node);
    setTimeout(() => node.remove(), isText ? 8500 : 2700);
  }

  // Inject keyframes once
  (function injectReactionStyles() {
    if (document.getElementById("__pp_styles")) return;
    const s = document.createElement("style");
    s.id = "__pp_styles";
    s.textContent = `
      @keyframes __pp_float {
        0%   { opacity: 0; transform: translateY(20px)  scale(0.6) rotate(-8deg); }
        15%  { opacity: 1; transform: translateY(0)     scale(1.1) rotate(2deg); }
        30%  {              transform: translateY(-30px) scale(1)   rotate(-2deg); }
        100% { opacity: 0; transform: translateY(-220px) scale(0.9) rotate(6deg); }
      }
      @keyframes __pp_slide {
        0%   { transform: translateX(0); }
        100% { transform: translateX(-150vw); }
      }
    `;
    (document.head || document.documentElement).appendChild(s);
  })();

  let currentDriftStatus = "waiting"; // waiting, sync, warning, out_of_sync, mismatch
  
  // ── Message Listener ───────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "REMOTE_SYNC") {
      applySync(message.state, message.serverNow);
    } else if (message.type === "CONNECTION_STATUS") {
      const wasConnected = connected;
      connected = !!message.connected;
      peerCount = message.peerCount || 0;
      updateOverlay();
      if (connected && !wasConnected) startTabInfoTimer();
      if (!connected && tabInfoTimer) { clearInterval(tabInfoTimer); tabInfoTimer = null; }
      if (connected) sendTabInfo();
    } else if (message.type === "SHOW_REACTION") {
      spawnReaction(message.emoji);
    } else if (message.type === "SYNC_STATUS") {
      // Don't claim any sync state until we actually have live data on both sides.
      // A partner record with just `{userId}` and no currentTime/url means they
      // haven't published a video yet — we should say "waiting", not "in sync".
      const hasLiveData = (m) =>
        m && typeof m.currentTime === "number" && typeof m.url === "string" &&
        typeof m.lastSeen === "number" && (message.serverNow - m.lastSeen) < 6000;

      if (peerCount < 2 || !hasLiveData(message.partner) || !hasLiveData(message.mine)) {
        currentDriftStatus = "waiting";
        updateOverlay();
        return;
      }

      const norm = u => { try { const url = new URL(u); return url.origin + url.pathname + url.search; } catch { return u; } };
      const mismatch = norm(message.mine.url) !== norm(message.partner.url);

      if (mismatch) {
        currentDriftStatus = "mismatch";
      } else if (message.mine.paused || message.partner.paused) {
        const drift = Math.abs((message.mine.currentTime || 0) - (message.partner.currentTime || 0));
        currentDriftStatus = drift > 1.5 ? "out_of_sync" : "sync";
      } else {
        const project = m => (m.currentTime || 0) + Math.max(0, (message.serverNow - m.lastSeen) / 1000);
        const drift = Math.abs(project(message.mine) - project(message.partner));

        if (drift > 2.0) currentDriftStatus = "out_of_sync";
        else if (drift > 0.8) currentDriftStatus = "warning";
        else currentDriftStatus = "sync";
      }
      updateOverlay();
      
    } else if (message.type === "GET_VIDEO_SNAPSHOT") {
      // Synchronous-ish: respond with current video state for sync-to-me
      if (!video) video = findVideo();
      if (!video) { sendResponse({ hasVideo: false }); return true; }
      sendResponse({
        hasVideo: true,
        currentTime: video.currentTime,
        playbackRate: video.playbackRate,
        paused: video.paused
      });
      return true;
    }
  });

  // ── Ad skipping (YouTube + yflix.to) ───────────────────────
  const host = location.hostname.replace(/^www\./, "");
  const isYouTube = /(^|\.)youtube\.com$/.test(host);
  const isYflix   = /(^|\.)yflix\.to$/.test(host);

  function showAdSkipFlash(label) {
    showFlash("play", label);
    // Override the icon to a "skip" glyph
    const flash = document.getElementById("__duet_flash");
    if (!flash) return;
    const icon = flash.querySelector("span");
    if (icon) icon.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 12 12" fill="none">' +
      '<path d="M2 1.5v9l6-4.5L2 1.5zM9 1.5h1.5v9H9z" fill="currentColor"/></svg>';
  }

  if (isYouTube) {
    let wasAd = false;
    ytAdTimer = setInterval(() => {
      if (!extAlive()) return;
      const player = document.querySelector(".html5-video-player");
      if (!player) return;
      const isAd = player.classList.contains("ad-showing") ||
                   player.classList.contains("ad-interrupting");
      adInProgress = isAd;

      if (isAd) {
        // Click the skip button if it's mounted
        const skip = player.querySelector(
          ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button"
        );
        if (skip) { try { skip.click(); } catch {} }

        // For unskippable ads: fast-forward the ad video to its end
        const ads = player.querySelectorAll("video");
        for (const v of ads) {
          if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.3) {
            try { v.currentTime = v.duration; } catch {}
          }
        }

        if (!wasAd) showAdSkipFlash("Skipped YouTube ad");
        wasAd = true;
      } else if (wasAd) {
        wasAd = false;
      }
    }, 400);
  }

  if (isYflix) {
    // 1. Popup-on-click ad blocking is now handled by yflix-main.js running in the MAIN world

    // 2. Hide common ad/banner DOM nodes
    const AD_SELECTORS = [
      'iframe[src*="ads"]', 'iframe[src*="ad."]', 'iframe[src*="exoclick"]',
      'iframe[src*="trafficjunky"]', 'iframe[src*="propeller"]', 'iframe[src*="popcash"]',
      'iframe[src*="adsterra"]', 'iframe[src*="hilltopads"]', 'iframe[src*="adnxs"]',
      'iframe[src*="doubleclick"]', 'iframe[src*="googlesyndication"]',
      '[id*="banner"]', '[id*="adslot"]', '[class*="banner-ad"]',
      '.ads', '.advertisement', '#ads', '.ad-container',
      'div[id^="ad_"]', 'div[class^="ad_"]', 'div[class*=" ad-"]'
    ];

    const HIDE_RULE = `${AD_SELECTORS.join(",")} { display:none !important; visibility:hidden !important; opacity:0 !important; pointer-events:none !important; height:0 !important; width:0 !important; }`;

    const styleEl = document.createElement("style");
    styleEl.id = "__duet_adhide";
    styleEl.textContent = HIDE_RULE;
    (document.head || document.documentElement).appendChild(styleEl);

    // 3. Intercept clicks on links that look like trackers/popunders
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a");
      if (!a) return;
      const href = a.href || "";
      const looksBad =
        a.target === "_blank" &&
        /(?:^|[\/.])(pop|ads?|click|redirect|track|out|go)\b/i.test(new URL(href, location.href).hostname + new URL(href, location.href).pathname);
      // Also block javascript: links that often trigger window.open
      if (looksBad || /^javascript:/i.test(href)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    }, true);

    // 4. Periodically try the skip button used by JW/Plyr-style players
    yflixSkipTimer = setInterval(() => {
      if (!extAlive()) return;
      const skip = document.querySelector(
        '.jw-skip, .jw-button-skip, .skip-ad, [class*="skip-ad" i], [aria-label*="skip" i]'
      );
      if (skip && skip.offsetParent !== null) {
        const now = Date.now();
        if (now - (skip.__pp_last_click || 0) < 3000) return;
        skip.__pp_last_click = now;
        try { skip.click(); } catch {}
      }
    }, 600);

    console.log("[Duet] yflix.to ad guard active.");
  }

  // ── Initial status fetch ───────────────────────────────────
  safeSend({ type: "GET_STATUS" }).then((status) => {
    if (status?.currentRoom) {
      connected = true;
      peerCount = status.peerCount || 1;
      updateOverlay();
      startTabInfoTimer();
      sendTabInfo();
    }
  });
})();
