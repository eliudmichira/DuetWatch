// ============================================================
//  Duet — Popup Script
// ============================================================

const $ = id => document.getElementById(id);

let currentRoomCode = null;
let myMeta = null;
let partnerMeta = null;
let togetherInfo = { since: null, total: 0 };
let serverClockOffset = 0;
let togetherTicker = null;
let lastDiag = null;

// ── Create / Join / Leave ──────────────────────────────────
$("create-btn").addEventListener("click", async () => {
  setBtnLoading("create-btn", "Creating…");
  clearMsg("main-msg");

  const res = await chrome.runtime.sendMessage({ type: "CREATE_ROOM" });
  setBtnLabel("create-btn", "Create a room");

  if (res?.error) { showMsg("main-msg", "error", res.error); return; }
  setConnectedState(res.roomCode, res.peerCount || 1);
});

$("join-btn").addEventListener("click", async () => {
  const code = $("join-code-input").value.trim().toUpperCase();
  if (code.length !== 6) {
    showMsg("main-msg", "error", "Room codes are exactly 6 characters.");
    return;
  }

  setBtnLoading("join-btn", "Joining…");
  clearMsg("main-msg");

  const res = await chrome.runtime.sendMessage({ type: "JOIN_ROOM", roomCode: code });
  setBtnLabel("join-btn", "Join room");

  if (res?.error) { showMsg("main-msg", "error", res.error); return; }
  setConnectedState(res.roomCode, 2);
});

$("join-code-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("join-btn").click();
});
$("join-code-input").addEventListener("input", (e) => {
  const cleaned = e.target.value.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 6);
  if (cleaned !== e.target.value) e.target.value = cleaned;
});

$("leave-btn").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "LEAVE_ROOM" });
  setDisconnectedState();
});

$("copy-code-btn").addEventListener("click", async () => {
  if (!currentRoomCode) return;
  try { await navigator.clipboard.writeText(currentRoomCode); } catch {}
  $("copy-code-btn").textContent = "✓ Copied to clipboard";
  $("copy-code-btn").classList.add("copied");
  setTimeout(() => {
    $("copy-code-btn").textContent = "Copy code";
    $("copy-code-btn").classList.remove("copied");
  }, 1800);
});

// ── Sync partner to me ─────────────────────────────────────
$("sync-me-btn").addEventListener("click", async () => {
  const btn = $("sync-me-btn");
  const label = btn.querySelector("span");
  const original = "Sync partner to me";
  btn.disabled = true;
  label.textContent = "Syncing…";

  const res = await chrome.runtime.sendMessage({ type: "SYNC_TO_ME" });

  if (res?.ok) {
    btn.classList.add("success");
    label.textContent = res.degraded === "no-force-rule" ? "Synced (rule fallback)" : "Synced ✓";
    if (res.degraded === "no-force-rule") {
      showMsg("main-msg", "warn", "Add the `force` field to your Firebase rules for instant sync.");
    }
    setTimeout(() => {
      btn.classList.remove("success");
      label.textContent = original;
      btn.disabled = false;
    }, 1800);
  } else {
    label.textContent = original;
    showMsg("main-msg", "error", res?.error || "Couldn't sync.");
    btn.disabled = false;
  }
});

// ── Reactions ──────────────────────────────────────────────
async function sendReactionLocalAndRemote(payload) {
  // Push to partner via Firebase
  chrome.runtime.sendMessage({ type: "SEND_REACTION", emoji: payload }).catch(() => {});
  // Also spawn it locally on the active tab so the sender gets visual feedback
  try {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { type: "SHOW_REACTION", emoji: payload }).catch(() => {});
    }
  } catch {}
}

$("reactions-tray").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-emoji]");
  if (!btn) return;
  sendReactionLocalAndRemote(btn.dataset.emoji);
  btn.classList.remove("flash");
  void btn.offsetWidth;
  btn.classList.add("flash");
});

const MAX_CHAT_LEN = 140;
$("chat-input").addEventListener("keydown", (e) => {
  if (e.key !== "Enter") return;
  const raw = $("chat-input").value.trim();
  if (!raw) return;
  const text = raw.slice(0, MAX_CHAT_LEN);
  sendReactionLocalAndRemote(text);
  $("chat-input").value = "";
  // Subtle confirmation flash on the input border
  const inp = $("chat-input");
  inp.style.borderColor = "var(--success)";
  setTimeout(() => { inp.style.borderColor = ""; }, 600);
});

$("chat-input").addEventListener("input", (e) => {
  if (e.target.value.length > MAX_CHAT_LEN) {
    e.target.value = e.target.value.slice(0, MAX_CHAT_LEN);
  }
});

// ── Open partner's URL ─────────────────────────────────────
$("open-partner-url").addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "OPEN_PARTNER_URL" });
  window.close();
});

// ── State Helpers ──────────────────────────────────────────
function setConnectedState(roomCode, peerCount) {
  currentRoomCode = roomCode;
  renderCodeCells(roomCode);
  $("view-disconnected").style.display = "none";
  $("view-connected").style.display = "block";
  $("status-dot").classList.add("connected");
  $("status-text").textContent = `Live · Room ${roomCode}`;
  updatePeerHint(peerCount);
}

function setDisconnectedState() {
  currentRoomCode = null;
  partnerMeta = null;
  myMeta = null;
  renderCodeCells(null);
  $("view-disconnected").style.display = "block";
  $("view-connected").style.display = "none";
  $("status-dot").classList.remove("connected");
  $("status-text").textContent = "Not connected";
}

function updatePeerHint(count) {
  const el = $("peer-hint");
  if (count >= 2) {
    // Once partner data lands, renderPartnerCard() will reflect "in sync".
    // Until then we just acknowledge they joined — don't overclaim.
    const live = partnerHasLiveData();
    const msg = live
      ? "Partner is here · play or pause to sync"
      : "Partner connected · waiting for their video…";
    el.innerHTML = `<span class="peer-dot connected"></span><span>${msg}</span>`;
    el.classList.add("ready");
    $("control-row").style.display = "flex";
    $("together-row").style.display = "inline-flex";
    $("chat-bar").style.display = "block";
  } else {
    el.innerHTML = `<span class="peer-dot"></span><span>Waiting for partner to join…</span>`;
    el.classList.remove("ready");
    $("control-row").style.display = "none";
    $("partner-card").style.display = "none";
    $("together-row").style.display = "none";
    $("chat-bar").style.display = "none";
  }
}

function renderCodeCells(code) {
  const host = $("room-code-display");
  host.innerHTML = "";
  const chars = (code || "------").padEnd(6, "-").split("").slice(0, 6);
  for (const ch of chars) {
    const cell = document.createElement("span");
    cell.textContent = ch;
    if (ch !== "-") cell.classList.add("filled");
    host.appendChild(cell);
  }
}

// ── Partner card ───────────────────────────────────────────
// Live: we have a fresh, complete record from the partner.
function partnerHasLiveData() {
  if (!partnerMeta) return false;
  if (typeof partnerMeta.currentTime !== "number") return false;
  if (typeof partnerMeta.url !== "string") return false;
  if (typeof partnerMeta.lastSeen !== "number") return false;
  const nowServer = Date.now() + serverClockOffset;
  return (nowServer - partnerMeta.lastSeen) < 6000;
}

function renderPartnerCard() {
  const card = $("partner-card");
  const peerHere = $("control-row").style.display === "flex"; // proxy for peerCount >= 2
  const live = partnerHasLiveData();

  // Hide the card entirely when there's no second peer.
  if (!peerHere) { card.style.display = "none"; return; }

  // Show the card whenever 2 peers are present, but render a *pending* state
  // until the partner publishes their first valid TAB_INFO.
  card.style.display = "block";
  card.classList.toggle("pending", !live);

  if (!live) {
    $("partner-host").textContent = "—";
    $("partner-title").textContent = "Waiting for partner's video…";
    $("partner-time-fill").style.width = "0%";
    $("partner-time-text").textContent = "—:— / —:—";
    $("partner-mismatch").style.display = "none";
    renderDrift(true); // hide drift pill while pending
    return;
  }

  $("partner-host").textContent = partnerMeta.hostname || "—";
  $("partner-title").textContent = partnerMeta.videoTitle || partnerMeta.pageTitle || "Untitled video";

  const cur = partnerMeta.currentTime || 0;
  const dur = partnerMeta.duration || 0;
  const pct = dur > 0 ? Math.min(100, (cur / dur) * 100) : 0;
  $("partner-time-fill").style.width = `${pct}%`;
  $("partner-time-text").textContent = `${fmtTime(cur)} / ${fmtTime(dur)}`;

  // Mismatch warning only when we have valid URLs on both sides.
  const mismatch = myMeta && myMeta.url && partnerMeta.url &&
    normalizeUrl(myMeta.url) !== normalizeUrl(partnerMeta.url);
  $("partner-mismatch").style.display = mismatch ? "flex" : "none";

  renderDrift(mismatch);
}

// ── Drift indicator ────────────────────────────────────────
function projectTime(meta) {
  // Returns the meta's currentTime advanced by the wall-clock seconds
  // since `lastSeen`, but only if it was playing. Pauseed → use as-is.
  if (!meta) return null;
  const baseTime = typeof meta.currentTime === "number" ? meta.currentTime : null;
  if (baseTime === null) return null;
  if (meta.paused) return baseTime;
  const ts = typeof meta.lastSeen === "number" ? meta.lastSeen : null;
  if (ts === null) return baseTime;
  const nowServer = Date.now() + serverClockOffset;
  return baseTime + Math.max(0, (nowServer - ts) / 1000);
}

function renderDrift(hideBecauseMismatch) {
  const pill = $("drift-pill");
  if (!pill) return;

  // Hide if we don't have both sides, or videos don't match, or either side is paused
  if (hideBecauseMismatch || !myMeta || !partnerMeta || myMeta.paused || partnerMeta.paused) {
    pill.style.display = "none";
    return;
  }

  const a = projectTime(myMeta);
  const b = projectTime(partnerMeta);
  if (a === null || b === null) { pill.style.display = "none"; return; }

  const drift = Math.abs(a - b);
  pill.style.display = "inline-flex";
  $("drift-text").textContent = drift < 10 ? `±${drift.toFixed(1)}s` : `±${Math.round(drift)}s`;

  pill.classList.remove("warn", "bad");
  if (drift > 2.0)      pill.classList.add("bad");
  else if (drift > 0.7) pill.classList.add("warn");
}

function normalizeUrl(u) {
  try {
    const url = new URL(u);
    return url.origin + url.pathname + url.search;
  } catch { return u; }
}

// ── Diagnostics rendering ──────────────────────────────────
function renderDiag(d) {
  if (!d) return;
  lastDiag = d;

  const now = Date.now();
  const sinceWrite   = d.lastWriteOk?.at  ? Math.round((now - d.lastWriteOk.at)  / 1000) : null;
  const sinceErr     = d.lastWriteErr?.at ? Math.round((now - d.lastWriteErr.at) / 1000) : null;
  const sincePartner = d.lastPartnerAt    ? Math.round((now - d.lastPartnerAt)   / 1000) : null;

  // Health: error in last 30s → red. Stale partner > 10s with peers → amber. Else green.
  const errFresh   = sinceErr !== null && sinceErr < 30;
  const partnerStale = d.peerCount >= 2 && (sincePartner === null || sincePartner > 10);

  const pill = $("diag-pill");
  const label = $("diag-label");
  pill.classList.remove("warn", "err");
  if (errFresh) {
    pill.classList.add("err");
    label.textContent = "Diagnostics · error";
  } else if (partnerStale) {
    pill.classList.add("warn");
    label.textContent = "Diagnostics · partner stale";
  } else {
    label.textContent = "Diagnostics · healthy";
  }

  // Banner: surface the most actionable hint
  const banner = $("diag-banner");
  const hint = (d.ruleHints && d.ruleHints.length) ? d.ruleHints[d.ruleHints.length - 1] : null;
  if (errFresh && d.lastWriteErr?.hint) {
    banner.textContent = d.lastWriteErr.hint;
    banner.className = "diag-banner";
    banner.style.display = "block";
  } else if (hint) {
    banner.textContent = hint;
    banner.className = "diag-banner warn";
    banner.style.display = "block";
  } else {
    banner.style.display = "none";
  }

  $("diag-last-ok").textContent  = d.lastWriteOk?.op  ? `${d.lastWriteOk.op} · ${fmtAgo(sinceWrite)}` : "—";
  $("diag-last-err").textContent = d.lastWriteErr?.op ? `${d.lastWriteErr.op} · ${fmtAgo(sinceErr)}`  : "—";
  $("diag-partner-at").textContent = sincePartner !== null ? fmtAgo(sincePartner) : "—";
  $("diag-peers").textContent = String(d.peerCount || 0);
  $("diag-me").textContent     = d.myUserId      || "—";
  $("diag-them").textContent   = d.partnerUserId || "—";
  $("diag-tab").textContent    = d.primaryTabId  != null ? `tab ${d.primaryTabId}` : "—";
}

function fmtAgo(sec) {
  if (sec === null || sec === undefined) return "—";
  if (sec < 1)   return "just now";
  if (sec < 60)  return `${sec}s ago`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const pad = n => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

// ── Live updates from background ───────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "POPUP_PEER_COUNT") {
    if (currentRoomCode) updatePeerHint(msg.peerCount);
  } else if (msg.type === "POPUP_PARTNER_META") {
    partnerMeta = msg.partner;
    myMeta = msg.mine;
    renderPartnerCard();
  } else if (msg.type === "POPUP_TOGETHER") {
    togetherInfo = msg.together || { since: null, total: 0 };
    if (typeof msg.serverNow === "number") serverClockOffset = msg.serverNow - Date.now();
    renderTogether();
  }
});

// ── Together-time counter ──────────────────────────────────
function currentSeconds() {
  const total = togetherInfo.total || 0;
  if (togetherInfo.since && typeof togetherInfo.since === "number") {
    const now = Date.now() + serverClockOffset;
    return total + Math.max(0, (now - togetherInfo.since) / 1000);
  }
  return total;
}

function renderTogether() {
  const el = $("together-text");
  if (!el) return;
  el.textContent = fmtTogether(currentSeconds());
}

function fmtTogether(sec) {
  sec = Math.floor(sec);
  if (sec < 60) return `${sec}s`;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  const s = sec % 60;
  return s ? `${m}m ${s}s` : `${m}m`;
}

// Tick the counter + drift every second while popup is open
function startTogetherTicker() {
  if (togetherTicker) clearInterval(togetherTicker);
  togetherTicker = setInterval(() => {
    renderTogether();
    renderPartnerCard();
    if (currentRoomCode) {
      const ready = $("peer-hint").classList.contains("ready");
      if (ready) updatePeerHint(2);
    }
    if (lastDiag) renderDiag(lastDiag); // re-tick "Xs ago" labels
  }, 1000);
}

// ── Helpers ────────────────────────────────────────────────
function showMsg(id, type, text) {
  const el = $(id);
  el.className = `msg ${type}`;
  el.textContent = text;
}
function clearMsg(id) { const el = $(id); el.className = "msg"; el.textContent = ""; }
function setBtnLoading(id, label) {
  const btn = $(id);
  btn.innerHTML = `<span class="spinner"></span> ${label}`;
  btn.disabled = true;
}
function setBtnLabel(id, label) {
  const btn = $(id);
  btn.textContent = label;
  btn.disabled = false;
}

// ── Init ───────────────────────────────────────────────────
(async () => {
  const status = await chrome.runtime.sendMessage({ type: "GET_STATUS" });
  if (status?.currentRoom) {
    setConnectedState(status.currentRoom, status.peerCount || 1);
    partnerMeta = status.partner;
    myMeta = status.mine;
    togetherInfo = status.together || { since: null, total: 0 };
    if (typeof status.serverNow === "number") serverClockOffset = status.serverNow - Date.now();
    renderPartnerCard();
    renderTogether();
    if (status.diag) renderDiag(status.diag);
    startTogetherTicker();
  } else {
    setDisconnectedState();
  }

  // Periodically poll while popup is open so the partner card and diag stay fresh
  setInterval(async () => {
    if (!currentRoomCode) return;
    const s = await chrome.runtime.sendMessage({ type: "GET_STATUS" });
    if (s?.currentRoom) {
      partnerMeta = s.partner;
      myMeta = s.mine;
      if (s.diag) renderDiag(s.diag);
      renderPartnerCard();
    }
  }, 2000);
})();
